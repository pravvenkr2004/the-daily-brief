# The Daily Brief — first website version

## What's included
- `index.html`: complete responsive bilingual website (English/Hindi)
- Category filters: Law, Politics, Technology, Education
- Article search and individual reading view
- Mobile-friendly layout
- Sample/demo articles clearly marked as examples

## Preview locally
Open `index.html` in a web browser.

## Publish free with GitHub Pages
1. Create or sign in to a free account at https://github.com/
2. Create a new **public** repository named `the-daily-brief`.
3. Upload `index.html` to the repository root (not inside another folder).
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. GitHub will show your live website URL, usually:
   https://YOUR-USERNAME.github.io/the-daily-brief/

## Before sharing publicly
- Replace `hello@example.com` with your real publication email.
- Replace the sample articles with original, fact-checked content.
- Add source links and publication dates to news reports.
- Do not present demo articles as breaking or current news.
- Add a privacy policy if you later collect visitor data, comments, or email subscriptions.

## Editing
You can edit `index.html` directly on GitHub: open the file, click the pencil icon, make changes, and commit.
